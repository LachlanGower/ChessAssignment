package model;

public enum PieceType
{
	BISHOP, KNIGHT, ROOK
}
