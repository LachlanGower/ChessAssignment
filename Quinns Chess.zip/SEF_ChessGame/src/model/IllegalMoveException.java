package model;

public class IllegalMoveException extends Exception
{
	public IllegalMoveException(String msg) {
		super(msg);
	}
}
