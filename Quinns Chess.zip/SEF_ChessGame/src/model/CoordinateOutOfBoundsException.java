package model;

public class CoordinateOutOfBoundsException extends Exception
{
	public CoordinateOutOfBoundsException(String msg){
		super(msg);
	}
}
