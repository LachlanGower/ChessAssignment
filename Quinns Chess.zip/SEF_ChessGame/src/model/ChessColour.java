package model;

public enum ChessColour
{
	BLACK, WHITE
}
