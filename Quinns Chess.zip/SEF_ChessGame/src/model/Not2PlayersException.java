package model;

public class Not2PlayersException extends Exception
{

}
